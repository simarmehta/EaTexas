__version__ = "1.0.1"

if __name__ == "__main__":  # pragma: no cover
    print(__version__)
