__version__ = "1.3.1"

if __name__ == "__main__":  # pragma: no cover
    print(__version__)
