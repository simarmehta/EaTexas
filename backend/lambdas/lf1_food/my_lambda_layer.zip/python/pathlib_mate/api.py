# -*- coding: utf-8 -*-

"""
Public API of this package.
"""

from .pathlib2 import Path
from .pathlib2 import WindowsPath
from .pathlib2 import PosixPath
from .pathlib2 import PathCls
from .pathlib2 import T_PATH_ARG
